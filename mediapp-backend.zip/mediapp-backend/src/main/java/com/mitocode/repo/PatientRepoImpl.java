package com.mitocode.repo;

import com.mitocode.model.Patient;
import org.springframework.stereotype.Repository;

//Estereotipos

//@Repository
public class PatientRepoImpl {//implements IPatientRepo{

    /*@Override
    public String sayHello(Patient patient){
        return  "Hi " + patient.getFirstName();
    }*/
}
