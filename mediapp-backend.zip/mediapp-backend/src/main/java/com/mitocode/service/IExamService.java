package com.mitocode.service;

import com.mitocode.model.Exam;

public interface IExamService extends ICRUD<Exam, Integer> {

}
