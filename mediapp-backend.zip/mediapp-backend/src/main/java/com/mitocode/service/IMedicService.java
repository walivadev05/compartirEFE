package com.mitocode.service;

import com.mitocode.model.Medic;

import java.util.List;

public interface IMedicService extends ICRUD<Medic, Integer> {

}
