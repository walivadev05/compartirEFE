export class Patient {
    idPatient: number;
    firstName: string;
    lastName: string;
    dni: string;
    address: string;
    phone: string;
    email: string;
}