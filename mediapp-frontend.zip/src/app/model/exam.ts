export class Exam {
    idExam: number;
    nameExam: string;
    descriptionExam: string;
}