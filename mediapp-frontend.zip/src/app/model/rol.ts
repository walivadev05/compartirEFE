export class Rol {
    idRol: number;
    name: string;
}