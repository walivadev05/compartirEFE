export class Specialty{
    idSpecialty: number;
    nameSpecialty: string;
    descriptionSpecialty: string;
}