export class ConsultDetail{
    diagnosis: string;
    treatment: string;
}