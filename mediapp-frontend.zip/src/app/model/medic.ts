export class Medic{
    idMedic: number;
    primaryName: string;
    surname: string;
    cmpMedic: string;
    photo: string;
}