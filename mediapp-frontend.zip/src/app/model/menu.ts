import { Rol } from "./rol";

export class Menu {
    idMenu: number;
    icon: string;
    name: string;
    url: string;
    roles: Rol[];
}