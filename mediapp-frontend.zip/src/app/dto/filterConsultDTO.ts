export class FilterConsultDTO{
    /*dni: string;
    fullname: string;

    constructor(dni: string, fullname: string){
        this.dni = dni;
        this.fullname = fullname;
    }*/

    constructor(public dni: string, public fullname: string){}
}