export const environment = {
    production: true,
    HOST: 'http://localhost:8080',
    REINTENTS: 2,
    TOKEN_NAME: 'jwtToken'
};
