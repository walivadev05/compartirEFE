export const environment = {
    production: false,
    HOST: 'http://localhost:8080',
    REINTENTS: 2,
    TOKEN_NAME: 'jwtToken'
};
