package com.mitocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicro1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
