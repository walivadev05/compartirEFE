package com.mitocode.service;

import com.mitocode.model.Medic;

public interface IMedicService extends ICRUD<Medic, Integer> {

}
