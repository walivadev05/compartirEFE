package com.mitocode.repo;

import com.mitocode.model.Exam;

public interface IExamRepo extends IGenericRepo<Exam, Integer>{

}
