package com.mitocode.repo;

import com.mitocode.model.Patient;

public interface IPatientRepo extends IGenericRepo<Patient, Integer>{

    //@Query("UPDATE Patient p SET p.status = 0 WHERE id = :id")
}
