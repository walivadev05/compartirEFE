package com.mitocode.repo;

//Estereotipos

//@Repository
public class PatientRepoImpl {//implements IPatientRepo{

    /*@Override
    public String sayHello(Patient patient){
        return  "Hi " + patient.getFirstName();
    }*/
}
