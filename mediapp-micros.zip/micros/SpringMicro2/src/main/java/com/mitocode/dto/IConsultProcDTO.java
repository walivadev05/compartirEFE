package com.mitocode.dto;

//JPA Projection
public interface IConsultProcDTO {

    Integer getQuantity();
    String getConsultDate();
}
